<!doctype html>
<!--[if IE 9]> <html class="no-js ie9 fixed-layout" lang="en"> <![endif]-->
<!--[if gt IE 9]><!--> <html class="no-js " lang="en"> <!--<![endif]-->
<head>

    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <!-- Mobile Meta -->
     <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, shrink-to-fit=no"/>
    
    <!-- Site Meta -->
    <title>Thank You</title>
    <meta name="keywords" content="study abroad , stdent application, How to Get a Canadian Student Visa, How to Get a Uk Student Visa, How to Get a USA Student Visa, How to Get a Newzeland Student Visa, How to Get a Sweden Student Visa, How to Get a EU Student Visa, How to Get a German Student Visa, Canadian study permit, student visa, Spous VISA, business visa, tier 1, tier 2, tier 4  visa application, I20, IELTS, IELTS Life Skills, Spoken English, Cultural immersion, british culture, IELTS Academic training,IELTS General training,IELTS UKVI (UK VISAS AND IMMIGRATION), speek in english, talk english, speaking, fluncey,SPEAKING TASKS, english lesson, english academy, english school, english training, english coaching, english courses, IELTS writing, IELTS reading, IELTS listening, Ielts speaking, IELTS BAND SCORE, IELTS BAND SCORE explained, Study in London, British university, UK univeristy, UK VISA, Uk Jobs, Uk work permit, UK marrage,study in UK, study in USA, study in Cyprus, study in Ireland, Study in Italy, study in Spain, study in Canada, study in Germany, study in Poland, study in Czech Republic, study in Singapoore, study in Portugal, study in Newzelad, study in Austraila, student consultency in Bangladesh, Think about study, Visa processing, IELTS In Bangladesh, english course in bangladesh, Ielts life skills in BD, bangladesh ielts, spoken english bangladesh, speaking hub bangladesh, english club BD, spoken english club in bangladesh, call ielts, book ielts in BD, book life skills, register IELTS in BD, Ielts registation, how to learn english language in bangladesh, how to learn english language in sylhet bangladesh, IELTS bangladesh test dates, ielts bangladesh registation, IELTS bangladesh result,IELTS bangladesh coaching, IELTS bangladesh dates, IELTS BD result, IELTS BD, IELTS BD coaching, IELTS BB cost, IELTS BC, IELTS BC exam dates, english in bangladesh, english in bangladesh education, teaching english in bangladesh, english course in bangladesh, IELTS course fee in BD, low price IELTS, ENGLISH teschers, IELTS sylhet, IELTS sylhet exam dates, sylhet IELTS center, sylhet IELTS course, sylhet IELTS exam center, sylhet IELTS preparation, sylhet IELTS center, IELTS zindabazar,IELTS Amborkhana, IELTS Uposhohor,IELTS Shibgonj, IELTS Kumarpara, IELTS course fee in sylhet, IELTS course in sylhet, IELTS preparation course in sylhet, best IELTS coaching in sylhet, IELTS preparation sylhet, IELTS life skills sylhet, life skills meaning, ielts life skills sylhet, IELTS Life Skills Centre Sylhet, IELTS Beanibazar, IELTS Golapganj, IELTS Habiganj District, IELTS Moulvi Bazar District, life skills Bishwanath Upazila, life skills BEANIBAZAR, IELTS Sunamganj District, IELTS life skills Sunamganj District, IELTS Al-Hamra Shopping City,IELTS Arcadia,IELTS life skills Al-Hamra Shopping City,IELTS  life skills Arcadia, sylhet city, spoken english sylhet, E1 Learning Academy IELTS, E1 Learning Academy IELTS Life Skills,E1 Learning Academy Spoken English,E1 Learning Academy Cultural Immersion, experience the difference, why e1, our courses, enrol now , contact e1, about us , our values, quality teaching,Why Choose Us?, Six reasons to choose E1,Free Online English Test, BDT 3900, BDT 7900, BDT 1900, BDT 1500, Request a Call Back, Get In Touch,Book Your Course,smart classroom, online learning, interactive learning"/>
	
	<meta name="description" content="We’re E1 Learning Academy. We are committed to make language more fun for learning enthusiastic whilst ensuring high standards."/>
	
	<meta name="abstract" content="We offer IELTS, IELTS Life Skills, Spoken English and Cultural Immeresion courese tailored to your needs with friendly environment. Founded by Graduates from British Universities with diverse industry experience. Start learning English with E1, Enrol Today. Sylhet Branch +8801300630691 e1learningacademy@gmail.com." />
	
	<meta name="author" content="E1 Learning Academy"/>
	<meta name="robots" content="index,follow"/>
	
	 <!-- Link Canonicalization -->
	
	<link rel="canonical" href="http://www.e1learningacademy.com/">

	
    
    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/4.png" type="image/x-icon" />
    <link rel="apple-touch-icon" href="images/4.png">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,700,900" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/css?family=Droid+Serif:400,400i,700,700i" rel="stylesheet"> 
    
    <!-- Custom & Default Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/carousel.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="style.css">

    <!--[if lt IE 9]>
        <script src="js/vendor/html5shiv.min.js"></script>
        <script src="js/vendor/respond.min.js"></script>
    <![endif]-->

</head>
<body>  

    <!-- LOADER -->
    <div id="preloader">
        <img class="preloader" src="images/loader.gif" alt="site loader">
    </div><!-- end loader -->
    <!-- END LOADER -->

    <div id="wrapper">
        <!-- BEGIN # MODAL LOGIN -->
        <div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
            <div class="modal-dialog">
                <div class="modal-content">
                    <!-- Begin # DIV Form -->
                    <div id="div-forms">
                        <form id="login-form">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span class="flaticon-add" aria-hidden="true"></span>
                            </button>
                            <div class="modal-body">
                                <input class="form-control" type="text" placeholder="What you are looking for?" required>
                            </div>
                        </form><!-- End # Login Form -->
                    </div><!-- End # DIV Form -->
                </div>
            </div>
        </div>
        <!-- END # MODAL LOGIN -->

        <header class="header header-normal">
            <div class="topbar clearfix">
                <div class="container">
                    <div class="row-fluid">
                       <div class="col-md-6 col-sm-6 text-left">
                            <p>
                              <strong><i class="fa fa-phone"></i></strong> <a href="tel:+8801300630691">+8801300630691</a> &nbsp;&nbsp;
							  <strong><i class="fa fa-envelope"></i></strong> <a href="mailto:e1learningacademy@gmail.com">e1learningacademy@gmail.com</a>
                            </p>
                        </div><!-- end left -->
                        <div class="col-md-6 col-sm-6 hidden-xs text-right">
                            <div class="social">
								
                                <a class="facebook" href="https://www.facebook.com/E1LearningAcademy/" target="_blank" data-tooltip="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook"></i></a> 
								
                                <a class="twitter" href="https://twitter.com/E1Academy" target="_blank" data-tooltip="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter"></i></a>
								
								<a class="youtube" href="https://www.youtube.com/channel/UCiOa_eFp7AravZvTJsGKnnA/featured?view_as=subscriber" target="_blank" data-tooltip="tooltip" data-placement="bottom" title="Youtube"><i class="fa fa-youtube"></i></a>
								
                                <a class="instagram" href="https://instagram.com/e1.learningacademy?igshid=v1mludpb8fwi" target="_blank" data-tooltip="tooltip" data-placement="bottom" title="Instagram"><i class="fa fa-instagram"></i></a>	
								
                            </div><!-- end social -->
                        </div><!-- end left -->
                    </div><!-- end row -->
                </div><!-- end container -->
            </div><!-- end topbar -->

            <div class="container">
                <nav class="navbar navbar-default yamm">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <div class="logo-normal">
                          <a class="navbar-brand" href="index.html" title="Home"><img src="images/4.png" alt="e1logo"></a>
                        </div>
                    </div>

                    <div id="navbar" class="navbar-collapse collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li><a href="index.html">Home</a></li>
                            <li class="dropdown hassubmenu">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">About Us<span class="fa fa-angle-down"></span></a>
                                <ul class="dropdown-menu" role="menu">
									<li><a href="whye1.html">Why E1</a></li>
                                    <li><a href="socialwork.html">Social Work</a></li>
                                    <li><a href="ourpartners.html">Our Partners</a></li>
                                </ul>
                            </li>
                            <li class="dropdown hassubmenu">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Courses <span class="fa fa-angle-down"></span></a>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="ielts.html">IELTS</a></li>
                                    <li><a href="lifeskills.html">Life Skills</a></li>
                                    <li><a href="spokenenglish.html">Spoken English</a></li>
                                    <li><a href="culturalimmersion.html">Cultural Immersion</a></li>
                                </ul>
                            </li>
							 <li><a href="gallery.html">Gallery</a></li>
                            <li><a href="contact.html">Contact Us</a></li>
                           
                        </ul>
                    </div>
                </nav><!-- end navbar -->
            </div><!-- end container -->
        </header>

        <section class="section db p120">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="tagline-message page-title text-center">
                            <h3>Thank You</h3>
                            <ul class="breadcrumb">
                                <li><a href="javascript:void(0)">E1</a></li>
                                <li class="active">Thank you for contacting us. We will be in touch with you at the earliest.</li>
                            </ul>
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </section><!-- end section -->

        <section class="section gb nopadtop">
            <div class="container">
				
				 
                <div class="boxed boxedp4">
					
                   <?php
$name = $_POST['name'];
$email = $_POST['email'];			 
$phone = $_POST['phone'];		
$message = $_POST['message'];
$email_from = "e1learningacademy@gmail.com";
$email_subject = "New Form Submission";
$email_body = "User Name: $name.\n".	
"User Email: $email.\n".
"User Phone: $phone.\n".
"User Message: $message.\n";
$to = "enquiry@e1learningacademy.com";
$headers = "From: $email_from \r\n";
$headers = "Reply To: $email \r\n";
mail($to,$email_subject,$email_body,$headers);
echo "";
?>	
		

                   <div class="map">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d57061.23999711254!2d91.81108437843271!3d24.925230928321774!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3750554eb71949fb%3A0x265af3dcf9de6baf!2sArtisan%20Coffee%20Co.!5e0!3m2!1sen!2sbd!4v1571131941963!5m2!1sen!2sbd">
		</iframe>
					 
	</div>
 <div class="row contactv2 text-center">
                        <div class="col-md-4">
                            <div class="small-box">
                                <i class="fa fa-phone"></i>
                                <h4>Contact us today</h4>
                                <small>Mobile: +8801300630691</small>
                                <small><a href="mailto:e1learningacademy@gmail.com">e1learningacademy@gmail.com</a></small>
                            </div><!-- end small-box -->
                        </div><!-- end col -->

                        <div class="col-md-4">
                            <div class="small-box">
                               <i class="fa fa-location-arrow"></i>
                                <h4>Visit Us</h4>
                                <small>39/A, Kumarpara Rd </small>
                                <small>Sylhet 3100, Bangladesh</small>
                            </div><!-- end small-box -->
                        </div><!-- end col -->

                        <div class="col-md-4">
                            <div class="small-box">
                                <i class="fa fa-clock-o"></i>
                                <h4>Opening Hours</h4>
                                <small>Sunday - Thursday (10am-8pm)</small>
								<small>Saturday (12pm-5pm) </small>
                            </div><!-- end small-box -->
                        </div><!-- end col -->
                    </div><!-- end contactv2 -->

                
                </div><!-- end container -->
            </div>
        </section>
		
		
       <footer class="section footer noover">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4">
                        <div class="widget clearfix">
                            <h3 class="widget-title">News & Insights </h3>
                            <div class="newsletter-widget">
								 <p>Stay informed with the latest in education news or watch webinars on-demand to get insights and be inspired.</p>
                                <p><a href="news-insights.html">Explore News & Insights</a></p>
                            </div><!-- end newsletter -->
                        </div><!-- end widget -->
                    </div><!-- end col -->

                    <div class="col-lg-3 col-md-3">
                        <div class="widget clearfix">
                            <h3 class="widget-title">Book Your Course</h3>
                            <p>Start learning with E1.Join us without losing time.</p>
                            <a href="enrol.html" class="readmore">Enrol Today</a>
                        </div><!-- end widget -->
                    </div><!-- end col -->

                    <div class="col-lg-3 col-md-3">
                        <div class="widget clearfix">
                            <h3 class="widget-title">Free Online English Test</h3>
							 <p>Our adaptive English Test can help you choose right course for you. Find out your English level in less than 20 minutes</p>
                            <div class="tags-widget">   
                                <ul class="list-inline">
                                    <li><a href="https://docs.google.com/forms/d/e/1FAIpQLSekVcNOzx4t0bdaS2_d_85BewTuSR_VrEDJozRf6kNoxfJehg/viewform?vc=0&c=0&w=1" target="_blank">Test 1: General English</a></li>
									
                                    <li><a href="https://docs.google.com/forms/d/e/1FAIpQLSfXc4RJtOLe_jANdSv4Oky18x3F1yWBgD8goTIV-3EYw1Thmw/viewform" target="_blank">Test 2: For Students</a></li>
									
                                    <li><a href="https://docs.google.com/forms/d/e/1FAIpQLSfpmtKGdSoiE6-vxJa6R66TTqEpqw0_KnVuvvwTZbLtX3O9qw/viewform" target="_blank">Test 3: For Advanced Users</a></li>  
                                </ul>
                            </div><!-- end list-widget -->
                        </div><!-- end widget -->
                    </div><!-- end col -->

                    <div class="col-lg-2 col-md-2">
                        <div class="widget clearfix">
                            <h3 class="widget-title">Support</h3>
                            <div class="list-widget">   
                                <ul>
                                    <li><a href="terms-conditions.html">Terms and Conditions</a></li>
									<li><a href="data-protection.html">Data Protection</a></li>
                                    <li><a href="accessibility-statement.html">Accessibility Statement</a></li>
									<li><a href="academic-policy.html">Academic Policy</a></li>
                                </ul>
                            </div><!-- end list-widget -->
                        </div><!-- end widget -->
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </footer><!-- end footer -->


        <div class="copyrights">
            <div class="container">
                <div class="clearfix">
                    <div class="pull-right">
                        <div class="social1">
                               <a class="facebook" href="https://www.facebook.com/E1LearningAcademy/" target="_blank" data-tooltip="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook"></i></a> 
								
                                <a class="twitter" href="https://twitter.com/E1Academy" target="_blank" data-tooltip="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter"></i></a>
								
								<a class="youtube" href="https://www.youtube.com/channel/UCiOa_eFp7AravZvTJsGKnnA/featured?view_as=subscriber" target="_blank" data-tooltip="tooltip" data-placement="bottom" title="Youtube"><i class="fa fa-youtube"></i></a>
								
                                <a class="instagram" href="https://instagram.com/e1.learningacademy?igshid=v1mludpb8fwi" target="_blank" data-tooltip="tooltip" data-placement="bottom" title="Instagram"><i class="fa fa-instagram"></i></a>
                            </div>
                    </div>

                    <div class="pull-left">
                        <div class="footer-links">
                            <ul class="list-inline">
                                <li> <a href="https://www.facebook.com/E1-Bespoke-Studio-107032944028686/" target="_blank">© 2019 |  E1 BESPOKE DESIGN </a></li>
								
                            </ul>
                        </div>
                    </div>
                </div>
            </div><!-- end container -->
        </div><!-- end copy -->
    </div><!-- end wrapper -->

    <!-- jQuery Files -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/carousel.js"></script>
    <script src="js/animate.js"></script>
    <script src="js/custom.js"></script>
    <!-- VIDEO BG PLUGINS -->
  

</body>
</html>